## Note: This package is deprecated in favor of the new [face-detection package](https://github.com/tensorflow/tfjs-models/blob/master/face-detection).
